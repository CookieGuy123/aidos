import React, { useState, useEffect } from "react";
import { Scholarship, Internship, College, BookmarkedOpportunity, NotificationItem } from "./types";
import ScholarshipsPanel from "./components/ScholarshipsPanel";
import InternshipsPanel from "./components/InternshipsPanel";
import DeadlinesPanel from "./components/DeadlinesPanel";
import AidCalculatorPanel from "./components/AidCalculatorPanel";
import ProfilePanel from "./components/ProfilePanel";
import { 
  Trophy, Bookmark, Clock, Calendar, ShieldCheck, 
  Sparkles, RefreshCw, Layers, Bell, CheckSquare, 
  ExternalLink, User, Settings, AlertTriangle, Play, Home,
  Sun, Moon, DollarSign
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"overview" | "scholarships" | "internships" | "deadlines" | "calculator" | "profile">("overview");
  
  // Theme & Preferences State
  const [theme, setTheme] = useState<"dark" | "light">(() => (localStorage.getItem("theme") as "dark" | "light") || "dark");
  const [homePageMode, setHomePageMode] = useState<"hub" | "profile">(() => (localStorage.getItem("homePageMode") as "hub" | "profile") || "hub");
  const [userName, setUserName] = useState(() => localStorage.getItem("userName") || "Student Explorer");
  const [userLevel, setUserLevel] = useState(() => localStorage.getItem("userLevel") || "undergrad");

  const handleThemeChange = (newTheme: "dark" | "light") => {
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
  };

  const handleHomePageModeChange = (newMode: "hub" | "profile") => {
    setHomePageMode(newMode);
    localStorage.setItem("homePageMode", newMode);
  };

  const handleUserNameChange = (newName: string) => {
    setUserName(newName);
    localStorage.setItem("userName", newName);
  };

  const handleUserLevelChange = (newLevel: string) => {
    setUserLevel(newLevel);
    localStorage.setItem("userLevel", newLevel);
  };
  
  // Data State
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [internships, setInternships] = useState<Internship[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [wonScholarships, setWonScholarships] = useState<{ [id: string]: number }>({});
  
  // State for Calculator link
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);

  // Status metrics
  const [isLoading, setIsLoading] = useState(true);
  const [notificationDrawerOpen, setNotificationDrawerOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: "note-1",
      title: "Upcoming Deadline Program",
      message: "Taco Bell Live Más Scholarship is ending soon (June 25, 2026)!",
      timestamp: "10 mins ago",
      isRead: false,
      type: "deadline"
    }
  ]);

  // Init Data Sync on Mount
  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setIsLoading(true);
    try {
      const schRes = await fetch("/api/scholarships");
      const schData = await schRes.json();
      setScholarships(schData);

      const intRes = await fetch("/api/internships");
      const intData = await intRes.json();
      setInternships(intData);
    } catch (e) {
      console.error("Failed to load initial directory records.", e);
    } finally {
      setIsLoading(false);
    }
  };

  // Trigger Gemini Crawler Engine (Google Search Grounding)
  const triggerScholarshipAIUpdate = async (query: string) => {
    const res = await fetch("/api/scholarships/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ searchQuery: query })
    });
    const data = await res.json();
    if (data.success) {
      setScholarships(data.scholarships);
      // Log notification
      addPushNotification(
        "AI Search Complete",
        `Successfully integrated ${data.addedCount || 3} verified scholarships for: "${query}"`,
        "system"
      );
    } else {
      throw new Error(data.error || "Web crawler index lookup failed.");
    }
  };

  const triggerInternshipAIUpdate = async (query: string) => {
    const res = await fetch("/api/internships/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ searchQuery: query })
    });
    const data = await res.json();
    if (data.success) {
      setInternships(data.internships);
      addPushNotification(
        "AI Internships Updated",
        `Discovered ${data.addedCount || 2} new student positions for: "${query}"`,
        "system"
      );
    } else {
      throw new Error(data.error || "Web crawler index lookup failed.");
    }
  };

  // Bookmarking System
  const handleToggleBookmark = (id: string, type: "scholarship" | "internship") => {
    if (bookmarks.includes(id)) {
      setBookmarks(bookmarks.filter(b => b !== id));
      addPushNotification("Bookmark Removed", `Removed item from watch list.`, "system");
    } else {
      setBookmarks([...bookmarks, id]);
      
      const matchedName = type === "scholarship" 
        ? scholarships.find(s => s.id === id)?.name 
        : internships.find(i => i.id === id)?.title;
        
      addPushNotification(
        "Opportunity Saved",
        `Added "${matchedName || "Opp"}" to favorites list. Watch for upcoming deadlines.`,
        "deadline"
      );
    }
  };

  // Won status manager
  const handleToggleWonStatus = (id: string, amount: number) => {
    setWonScholarships(prev => {
      const updated = { ...prev };
      if (amount === 0) {
        delete updated[id];
        addPushNotification("Award Removed", "Scholarship won status cleared.", "system");
      } else {
        updated[id] = amount;
        addPushNotification("Award Secured!", `Marked as won: +$${amount.toLocaleString()}! Added to financial calculator.`, "alert");
      }
      return updated;
    });
  };

  // Manual insertions
  const handleAddManualScholarship = (newSch: Scholarship) => {
    setScholarships(prev => {
      const updated = [newSch, ...prev];
      addPushNotification("Manual Track Added", `Created: "${newSch.name}"`, "system");
      return updated;
    });
  };

  const handleAddManualInternship = (newInt: Internship) => {
    setInternships(prev => {
      const updated = [newInt, ...prev];
      addPushNotification("Manual Internship Tracked", `Created: "${newInt.title}"`, "system");
      return updated;
    });
  };

  // Pre-load collegiate cost details to calculator
  const handleSelectCollegeForCalculator = (college: College) => {
    setSelectedCollege(college);
    setActiveTab("calculator");
    addPushNotification(
      "College Pre-Loaded",
      `Sticker cost for ${college.name} loaded into out-of-pocket projection tool.`,
      "system"
    );
  };

  // Reset database state to original templates
  const handleResetDatabase = async () => {
    if (window.confirm("Restore pre-seeded safe-mode scholarships & internships?")) {
      const res = await fetch("/api/reset", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        fetchInitialData();
        setBookmarks([]);
        setWonScholarships({});
        addPushNotification("System Settings", "All application structures successfully restored.", "system");
      }
    }
  };

  // Push Notifications API
  const addPushNotification = (title: string, message: string, type: "deadline" | "alert" | "system") => {
    const newItem: NotificationItem = {
      id: `note-${Date.now()}`,
      title,
      message,
      timestamp: "Just now",
      isRead: false,
      type
    };
    setNotifications(prev => [newItem, ...prev]);

    // Request permissions checks if available, simulate browser notification if focused outside
    if (Notification.permission === "granted") {
      new Notification(`[Holo Academic] ${title}`, {
        body: message,
        icon: "/assets/favicon.ico"
      });
    }
  };

  // Calculations for dashboard indicators
  const totalWonTotalValue = (Object.values(wonScholarships) as number[]).reduce((acc: number, curr: number) => acc + curr, 0);
  const bookmarkedCount = bookmarks.length;

  return (
    <div className={`min-h-screen bg-holo-black text-white font-sans flex flex-col justify-between selection:bg-holo-blue-dark selection:text-black ${theme === "light" ? "theme-light" : ""}`}>
      
      {/* Android Action Bar resembling modern clean styling */}
      <header className="h-14 flex items-center justify-between px-4 border-b border-holo-gray-border bg-holo-black shrink-0 relative">
        <div className="flex items-center gap-3">
          <button 
            className="w-8 h-8 rounded-sm bg-holo-blue-light text-black flex items-center justify-center hover:bg-white hover:text-black transition-all cursor-pointer" 
            onClick={() => setActiveTab("overview")}
            title="Go to Home Overview"
          >
            <Home className="w-4 h-4" />
          </button>
          <div>
            <h1 className="text-base tracking-tight font-medium flex items-center">
              Academic Discovery Hub
            </h1>
          </div>
        </div>

        {/* Global Action items */}
        <div className="flex items-center gap-3">
          {/* Global Stats */}
          <div className="hidden md:flex items-center gap-6 text-xs text-gray-400">
            <div className="flex items-center gap-1.5">
              <Bookmark className="w-4 h-4 text-holo-blue-light" />
              <span>Bookmarked: <strong className="text-white">{bookmarkedCount}</strong></span>
            </div>
            <button 
              onClick={handleResetDatabase}
              className="border border-holo-gray-border bg-holo-gray-light hover:bg-holo-blue-dim hover:text-holo-blue-light py-1 px-2.5 text-xs transition-all cursor-pointer"
              title="Reset databases to pre-seeded list"
            >
              Reset Sample Data
            </button>
          </div>

          {/* Theme switcher */}
          <button
            onClick={() => handleThemeChange(theme === "dark" ? "light" : "dark")}
            className="w-8 h-8 rounded-sm border border-holo-gray-border bg-holo-gray-light text-holo-blue-light flex items-center justify-center hover:bg-holo-blue-dim transition-all cursor-pointer"
            title={`Switch to ${theme === "dark" ? "Light" : "Dark"} Mode`}
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Tabs Navigation Bar */}
      <nav className="flex bg-[#0b0f15] border-b border-holo-gray-border shrink-0 select-none font-sans">
        <button
          onClick={() => setActiveTab("overview")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "overview"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab("scholarships")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "scholarships"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Scholarships
        </button>
        <button
          onClick={() => setActiveTab("internships")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "internships"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Internships
        </button>
        <button
          onClick={() => setActiveTab("deadlines")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "deadlines"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Deadlines
        </button>
        <button
          onClick={() => setActiveTab("calculator")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "calculator"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Calculator
        </button>
        <button
          onClick={() => setActiveTab("profile")}
          className={`flex-1 py-3 text-center border-b-2 text-xs font-semibold tracking-tight transition-all cursor-pointer ${
            activeTab === "profile"
              ? "border-holo-blue-light text-holo-blue-light bg-holo-blue-dim/10 font-bold"
              : "border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          Profile
        </button>
      </nav>

      {/* Main Content Area */}
      <main className="flex-grow p-4 md:p-6 overflow-y-auto max-w-7xl w-full mx-auto">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center p-20 space-y-3 font-sans text-xs text-holo-blue-light animate-pulse">
            <RefreshCw className="w-6 h-6 animate-spin" />
            <span>Gathering student opportunities...</span>
          </div>
        ) : (
          <>
            {/* 1. Overview Tab (Dashboard) */}
            {activeTab === "overview" && (
              homePageMode === "profile" ? (
                <ProfilePanel
                  userName={userName}
                  userLevel={userLevel}
                  onChangeUserName={handleUserNameChange}
                  onChangeUserLevel={handleUserLevelChange}
                  homePageMode={homePageMode}
                  onChangeHomePageMode={handleHomePageModeChange}
                  theme={theme}
                  onChangeTheme={handleThemeChange}
                  bookmarks={bookmarks}
                  scholarships={scholarships}
                  internships={internships}
                  onToggleBookmark={handleToggleBookmark}
                  wonScholarships={wonScholarships}
                  onToggleWonStatus={handleToggleWonStatus}
                  onResetDatabase={handleResetDatabase}
                />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  {/* Console Hub (Dashboard Grid) */}
                  <div className="md:col-span-8 space-y-6">
                    {/* Summary Banner greeting */}
                    <div className="bg-gradient-to-r from-holo-blue-dim/30 to-transparent border border-holo-gray-border p-6 relative">
                      <div className="absolute top-0 left-0 bottom-0 w-1 bg-holo-blue-light shadow-[0_0_8px_#33b5e5]" />
                      <span className="text-[10px] font-mono text-holo-blue-light uppercase tracking-wider font-bold block mb-1">
                        Welcome back, {userName}
                      </span>
                      <h2 className="text-2xl font-light uppercase tracking-tight text-white">
                        Student Admission & Financial Aid Console
                      </h2>
                      <p className="text-xs text-gray-400 mt-2 leading-relaxed font-sans">
                        Your central control hub. Navigate through scholarships, track deadlines, project college costs, and manage your student credentials.
                      </p>
                    </div>

                    {/* Bento Grid Hub Shortcuts */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Shortcut: Scholarships */}
                      <div 
                        onClick={() => setActiveTab("scholarships")}
                        className="bg-holo-gray-dark border border-holo-gray-border p-5 hover:border-holo-blue-light/50 transition-all cursor-pointer group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 p-3 text-holo-blue-light/20 group-hover:text-holo-blue-light/40 transition-all">
                          <Trophy className="w-10 h-10" />
                        </div>
                        <h4 className="text-sm font-bold font-sans text-white uppercase group-hover:text-holo-blue-light transition-all">
                          Scholarship Search
                        </h4>
                        <p className="text-2xs text-gray-400 mt-1 font-sans leading-relaxed">
                          Query live records using AI web search. Filter safe and verified listings.
                        </p>
                        <span className="text-[10px] text-holo-blue-light font-mono mt-3 inline-block uppercase">
                          Open Finder &rarr;
                        </span>
                      </div>

                      {/* Shortcut: Internships */}
                      <div 
                        onClick={() => setActiveTab("internships")}
                        className="bg-holo-gray-dark border border-holo-gray-border p-5 hover:border-holo-blue-light/50 transition-all cursor-pointer group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 p-3 text-holo-blue-light/20 group-hover:text-holo-blue-light/40 transition-all">
                          <Layers className="w-10 h-10" />
                        </div>
                        <h4 className="text-sm font-bold font-sans text-white uppercase group-hover:text-holo-blue-light transition-all">
                          Internship Finder
                        </h4>
                        <p className="text-2xs text-gray-400 mt-1 font-sans leading-relaxed">
                          Scan engineering, health, and business opportunities, and flag scams.
                        </p>
                        <span className="text-[10px] text-holo-blue-light font-mono mt-3 inline-block uppercase">
                          Browse Openings &rarr;
                        </span>
                      </div>

                      {/* Shortcut: Deadlines */}
                      <div 
                        onClick={() => setActiveTab("deadlines")}
                        className="bg-holo-gray-dark border border-holo-gray-border p-5 hover:border-holo-blue-light/50 transition-all cursor-pointer group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 p-3 text-holo-blue-light/20 group-hover:text-holo-blue-light/40 transition-all">
                          <Clock className="w-10 h-10" />
                        </div>
                        <h4 className="text-sm font-bold font-sans text-white uppercase group-hover:text-holo-blue-light transition-all">
                          College Deadlines
                        </h4>
                        <p className="text-2xs text-gray-400 mt-1 font-sans leading-relaxed">
                          Monitor admissions cycles, sticker tuition rates, and application dates.
                        </p>
                        <span className="text-[10px] text-holo-blue-light font-mono mt-3 inline-block uppercase">
                          View Calendar &rarr;
                        </span>
                      </div>

                      {/* Shortcut: Net Price Calculator */}
                      <div 
                        onClick={() => setActiveTab("calculator")}
                        className="bg-holo-gray-dark border border-holo-gray-border p-5 hover:border-holo-blue-light/50 transition-all cursor-pointer group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 p-3 text-holo-blue-light/20 group-hover:text-holo-blue-light/40 transition-all">
                          <DollarSign className="w-10 h-10" />
                        </div>
                        <h4 className="text-sm font-bold font-sans text-white uppercase group-hover:text-holo-blue-light transition-all">
                          Net Cost Calculator
                        </h4>
                        <p className="text-2xs text-gray-400 mt-1 font-sans leading-relaxed">
                          Project out-of-pocket costs with tuition loading and won grant deductions.
                        </p>
                        <span className="text-[10px] text-holo-blue-light font-mono mt-3 inline-block uppercase">
                          Open Calculator &rarr;
                        </span>
                      </div>

                      {/* Shortcut: Profile */}
                      <div 
                        onClick={() => setActiveTab("profile")}
                        className="bg-holo-gray-dark border border-holo-gray-border p-5 hover:border-holo-blue-light/50 transition-all cursor-pointer group relative overflow-hidden sm:col-span-2"
                      >
                        <div className="absolute top-0 right-0 p-3 text-holo-blue-light/20 group-hover:text-holo-blue-light/40 transition-all">
                          <User className="w-10 h-10" />
                        </div>
                        <h4 className="text-sm font-bold font-sans text-white uppercase group-hover:text-holo-blue-light transition-all">
                          My Profile & Preferences
                        </h4>
                        <p className="text-2xs text-gray-400 mt-1 font-sans leading-relaxed">
                          Edit student credentials, toggle preferences, customize your homepage mode, switch themes, and review saved opportunities.
                        </p>
                        <span className="text-[10px] text-holo-blue-light font-mono mt-3 inline-block uppercase">
                          Open Settings &rarr;
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Vertical side column: Notifications */}
                  <div className="md:col-span-4 space-y-6">
                    <div className="bg-holo-gray-dark border border-holo-gray-border p-4 h-full flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-center border-b border-holo-gray-border pb-2 mb-3">
                          <h3 className="text-xs text-holo-blue-light uppercase font-bold tracking-wider flex items-center gap-1.5 font-sans">
                            <Bell className="w-4 h-4" />
                            Notifications & Alerts
                          </h3>
                          {notifications.some(n => !n.isRead) && (
                            <span className="bg-holo-blue-light text-black text-[9px] font-bold px-1.5 uppercase animate-pulse">Alerts</span>
                          )}
                        </div>

                        <div className="space-y-3.5 max-h-[350px] overflow-y-auto">
                          {notifications.length === 0 ? (
                            <div className="text-center text-xs text-gray-500 py-6 font-sans">
                              No active notifications.
                            </div>
                          ) : (
                            notifications.map(n => (
                              <div 
                                key={n.id} 
                                className={`p-2.5 border text-xs font-sans relative group ${
                                  n.isRead ? "bg-black/40 border-gray-900 text-gray-500" : "bg-holo-blue-dim/10 border-holo-blue-dark/30 text-gray-200"
                                }`}
                              >
                                <div 
                                  onClick={() => {
                                    setNotifications(prev => prev.map(item => item.id === n.id ? { ...item, isRead: true } : item));
                                  }}
                                  className="cursor-pointer pr-6"
                                >
                                  <div className="flex justify-between items-center mb-1">
                                    <span className="font-bold text-holo-blue-light uppercase text-[10px] tracking-wide select-none">&bull; {n.title}</span>
                                    <span className="text-[9px] text-gray-500 font-normal">{n.timestamp}</span>
                                  </div>
                                  <p className="leading-relaxed font-sans">{n.message}</p>
                                </div>
                                
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setNotifications(prev => prev.filter(item => item.id !== n.id));
                                  }}
                                  className="absolute top-2.5 right-2.5 text-gray-500 hover:text-red-400 font-mono text-xs cursor-pointer font-bold opacity-60 group-hover:opacity-100 transition-opacity"
                                  title="Dismiss notification"
                                >
                                  &times;
                                </button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      <button 
                        onClick={() => setNotifications([])}
                        className="w-full mt-4 bg-black border border-holo-gray-border text-gray-400 hover:text-red-400 hover:border-red-500/50 transition-all text-xs font-sans uppercase py-1.5 cursor-pointer text-center"
                      >
                        DISMISS ALL NOTIFICATIONS
                      </button>
                    </div>
                  </div>
                </div>
              )
            )}

            {/* 2. Scholarships Panel */}
            {activeTab === "scholarships" && (
              <ScholarshipsPanel
                scholarships={scholarships}
                bookmarks={bookmarks}
                wonScholarships={wonScholarships}
                isLoading={isLoading}
                onToggleBookmark={handleToggleBookmark}
                onToggleWonStatus={handleToggleWonStatus}
                onTriggerAIUpdate={triggerScholarshipAIUpdate}
                setIsAddingManual={() => {}}
                onAddManualScholarship={handleAddManualScholarship}
              />
            )}

            {/* 3. Internships Panel */}
            {activeTab === "internships" && (
              <InternshipsPanel
                internships={internships}
                bookmarks={bookmarks}
                isLoading={isLoading}
                onToggleBookmark={handleToggleBookmark}
                onTriggerAIUpdate={triggerInternshipAIUpdate}
                onAddManualInternship={handleAddManualInternship}
              />
            )}

            {/* 4. Deadlines Panel */}
            {activeTab === "deadlines" && (
              <DeadlinesPanel
                onSelectCollegeForCalculator={handleSelectCollegeForCalculator}
              />
            )}

            {/* 5. Financial Calculator Panel */}
            {activeTab === "calculator" && (
              <AidCalculatorPanel
                preselectedCollege={selectedCollege}
                totalScholarshipsWon={totalWonTotalValue}
              />
            )}

            {/* 6. Profile Panel */}
            {activeTab === "profile" && (
              <ProfilePanel
                userName={userName}
                userLevel={userLevel}
                onChangeUserName={handleUserNameChange}
                onChangeUserLevel={handleUserLevelChange}
                homePageMode={homePageMode}
                onChangeHomePageMode={handleHomePageModeChange}
                theme={theme}
                onChangeTheme={handleThemeChange}
                bookmarks={bookmarks}
                scholarships={scholarships}
                internships={internships}
                onToggleBookmark={handleToggleBookmark}
                wonScholarships={wonScholarships}
                onToggleWonStatus={handleToggleWonStatus}
                onResetDatabase={handleResetDatabase}
              />
            )}
          </>
        )}
      </main>


    </div>
  );
}
