import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Pre-seeded database for Scholarships
const defaultScholarships = [
  {
    id: "sch-gates",
    name: "The Gates Scholarship",
    organization: "The Bill & Melinda Gates Foundation",
    amount: "$55,000 / year (Full cost of attendance)",
    amountNumeric: 55000,
    deadline: "2026-09-15",
    studentLevel: "high_school",
    ageFilter: "Under 19",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["Pell-eligible", "Minority status", "GPA 3.3+", "US Citizen"],
    isVerified: true,
    fieldOfStudy: "Any",
    sourceUrl: "https://www.thegatesscholarship.org",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-cocacola",
    name: "Coca-Cola Scholars Program",
    organization: "Coca-Cola Scholars Foundation",
    amount: "$20,000 total",
    amountNumeric: 20000,
    deadline: "2026-10-31",
    studentLevel: "high_school",
    ageFilter: "High school senior",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["GPA 3.0+", "High school senior", "US Citizen/Resident", "Leadership & Service"],
    isVerified: true,
    fieldOfStudy: "Any",
    sourceUrl: "https://www.coca-colascholarsfoundation.org",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-smart-dod",
    name: "SMART Scholarship Program",
    organization: "U.S. Department of Defense (DoD)",
    amount: "$38,000 / year + Full Tuition",
    amountNumeric: 38000,
    deadline: "2026-12-01",
    studentLevel: "college",
    ageFilter: "Minimum 18",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["Majoring in STEM field", "GPA 3.0+", "US Citizen", "Willing to accept summer internships"],
    isVerified: true,
    fieldOfStudy: "STEM",
    sourceUrl: "https://www.smartscholarship.org",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-goldwater",
    name: "Barry Goldwater Scholarship",
    organization: "Goldwater Foundation",
    amount: "$7,500 / year",
    amountNumeric: 75000, // $7,500, typo check
    deadline: "2027-01-30",
    studentLevel: "college",
    ageFilter: "Sophomore or Junior",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["GPA 3.7+", "Majoring in STEM field", "Intending to pursue research career"],
    isVerified: true,
    fieldOfStudy: "STEM",
    sourceUrl: "https://goldwater.scholarsapply.org",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-tacobell",
    name: "Taco Bell Live Más Scholarship",
    organization: "Taco Bell Foundation",
    amount: "$25,000 total",
    amountNumeric: 25000,
    deadline: "2026-06-25", // Ending soon!
    studentLevel: "both",
    ageFilter: "16 to 26",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["Submit a 2-minute video about your passion", "Must not be standard academic/athletic focus"],
    isVerified: true,
    fieldOfStudy: "Any",
    sourceUrl: "https://www.tacobellfoundation.org/live-mas-scholarship/",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-horatio-alger",
    name: "Horatio Alger National Scholarship",
    organization: "Horatio Alger Association",
    amount: "$25,000 total",
    amountNumeric: 25000,
    deadline: "2026-06-15", // Ending soonest
    studentLevel: "high_school",
    ageFilter: "High school junior",
    isFree: true,
    scamFlag: false,
    scamReason: "",
    requirements: ["Financial need ($55k or less family income)", "GPA 2.0+", "US Citizen"],
    isVerified: true,
    fieldOfStudy: "Any",
    sourceUrl: "https://scholars.horatioalger.org",
    originalQuery: "Pre-seeded list"
  },
  {
    id: "sch-scam-essay",
    name: "Fast-Track Platinum Merit Scholarship",
    organization: "Independent Scholarship Reviewers Group",
    amount: "$15,000 total",
    amountNumeric: 15000,
    deadline: "2026-07-15",
    studentLevel: "both",
    ageFilter: "All ages",
    isFree: false,
    scamFlag: true,
    scamReason: "Requires a non-refundable $15 processing fee to file your application, which is a classic scholarship scam trait.",
    requirements: ["No GPA requirement", "Pay the review fee to get evaluated", "Submit high school essay"],
    isVerified: false,
    fieldOfStudy: "Any",
    sourceUrl: "http://example-scam-domain.com/pay-fee",
    originalQuery: "Pre-seeded list"
  }
];

// Pre-seeded database for Internships
const defaultInternships = [
  {
    id: "int-google-swe",
    title: "Software Engineering Intern",
    company: "Google",
    location: "Remote or Hybrid (Mountain View, CA)",
    type: "Paid",
    deadline: "2026-10-15",
    studentLevel: "undergrad",
    description: "Work on Google's core products, build scalable systems, and write high-quality code in Python, C++, Java, or Go alongside senior mentors.",
    requirements: ["Enrolled in BS, MS, or PhD in Computer Science or related", "Experience with standard coding algorithms"],
    isVerified: true,
    scamFlag: false,
    scamReason: "",
    sourceUrl: "https://careers.google.com",
    fieldOfStudy: "Engineering"
  },
  {
    id: "int-microsoft-explore",
    title: "Explore Microsoft Intern",
    company: "Microsoft",
    location: "On-site / Hybrid (Redmond, WA)",
    type: "Paid",
    deadline: "2026-09-30",
    studentLevel: "undergrad",
    description: "A 12-week rotational internship for freshman or sophomore college students, experiencing both Software Engineering and Program Management roles.",
    requirements: ["Freshman or sophomore in college", "Interest in Software Development or tech careers"],
    isVerified: true,
    scamFlag: false,
    scamReason: "",
    sourceUrl: "https://careers.microsoft.com",
    fieldOfStudy: "Engineering"
  },
  {
    id: "int-nasa-pathways",
    title: "NASA Pathways Intern Program",
    company: "NASA Goddard Space Flight Center",
    location: "On-site / Greenbelt, MD",
    type: "Paid",
    deadline: "2026-11-15",
    studentLevel: "undergrad",
    description: "Paid experience integrating academics with practical engineering and science projects supporting deep-space communications and telemetry.",
    requirements: ["Enrollment in accredited degree program", "GPA 3.0+", "US Citizen"],
    isVerified: true,
    scamFlag: false,
    scamReason: "",
    sourceUrl: "https://www.nasa.gov/careers",
    fieldOfStudy: "Engineering"
  },
  {
    id: "int-nih-biomed",
    title: "Summer Biomedical Research Intern",
    company: "National Institutes of Health (NIH)",
    location: "On-site (Bethesda, MD)",
    type: "Paid",
    deadline: "2027-01-15",
    studentLevel: "undergrad",
    description: "Work with lead investigators in medical laboratories studying viral genetics, immunology, oncology, and public health metrics.",
    requirements: ["Enrolled in undergrad biology, pre-med, or health science", "GPA 3.2+"],
    isVerified: true,
    scamFlag: false,
    scamReason: "",
    sourceUrl: "https://www.training.nih.gov",
    fieldOfStudy: "Health"
  },
  {
    id: "int-deloitte-consult",
    title: "Business & Consulting Summer Associate",
    company: "Deloitte",
    location: "Hybrid (New York, NY)",
    type: "Paid",
    deadline: "2026-08-31",
    studentLevel: "undergrad",
    description: "Support clients on corporate restructuring, cloud transformation planning, digital product roadmaps, and stakeholder interviews.",
    requirements: ["Junior year student in Business, Finance, Economics, or STEM", "Strong presentation skills"],
    isVerified: true,
    scamFlag: false,
    scamReason: "",
    sourceUrl: "https://www.deloitte.com/careers",
    fieldOfStudy: "Business"
  },
  {
    id: "int-unverified-scam",
    title: "Vigilant Security Services Remote Agent",
    company: "Security Vault Processing LLC",
    location: "Remote (100% Home)",
    type: "Unpaid",
    deadline: "2026-07-20",
    studentLevel: "all",
    description: "Simple task-handling position. Receive client payments in checks and wire transfers to local accounts. Training fee of $45 is required.",
    requirements: ["Must have personal US bank account", "Pay $45 registration upfront for credential validation"],
    isVerified: false,
    scamFlag: true,
    scamReason: "Asks candidates to process payments/wire deposits through their personal account and charges an upfront entry registration fee.",
    sourceUrl: "http://unverified-recruitment-portal.net",
    fieldOfStudy: "Business"
  }
];

// In-memory array that expands during the application lifecycle
let dynamicScholarships = [...defaultScholarships];
let dynamicInternships = [...defaultInternships];

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Reset databases to pre-seeded datasets
  app.post("/api/reset", (req, res) => {
    dynamicScholarships = [...defaultScholarships];
    dynamicInternships = [...defaultInternships];
    res.json({ success: true, message: "Databases successfully restored to pre-seeded templates." });
  });

  // API Route: Get Scholarships list
  app.get("/api/scholarships", (req, res) => {
    res.json(dynamicScholarships);
  });

  // API Route: Use Gemini with Google Search tool to search and verify scholarships
  app.post("/api/scholarships/update", async (req, res) => {
    const { searchQuery } = req.body;
    const query = searchQuery || "reputable high school seniors and college student scholarships 2026 2027";

    console.log(`[AI Update Engine] Fetching new scholarships from reputable sources with query: "${query}"`);

    const geminiKey = process.env.GEMINI_API_KEY;
    if (!geminiKey || geminiKey === "MY_GEMINI_API_KEY") {
      console.log("[AI Update Engine] GEMINI_API_KEY is not configured. Falling back to pre-seeded listings.");
      return res.json({
        success: false,
        error: "GEMINI_API_KEY is not configured in the system Secrets. Showing default pre-seeded scholarships.",
        scholarships: dynamicScholarships
      });
    }

    try {
      const ai = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Search Google for real, currently open or upcoming scholarships with search phrase or query: "${query}". 
Identify at least 3 legitimate active opportunities. For EACH scholarship, extract:
1. Scholarship Name
2. Governing Organization
3. Approximate Award Amount (as a string, and also a pure estimated numeric value)
4. Application Deadline (as YYYY-MM-DD or "Recurring")
5. Eligibility Level: must be one of "high_school", "college", or "both"
6. Standard age restriction description or limit (e.g. "Under 19" or "None")
7. Application Fee requirement (is it completely free to apply?)
8. SUSPECTED SCAM check: Differentiate real and legitimate opportunities from scams. If a scholarship demands an application fee, processing fee, or asks for highly sensitive financial credentials like SSN/Credit Card upfront, set scamFlag to true and provide a thorough reason.
9. Required criteria/academic grades
10. Authentic source URL.

Your response MUST be a single raw JSON array conforming EXACTLY to the following TypeScript syntax:
\`\`\`json
[
  {
    "id": "sch-[unique string]",
    "name": "Scholarship Name",
    "organization": "Sponsoring Organization",
    "amount": "$5,000 total",
    "amountNumeric": 5000,
    "deadline": "2026-11-15",
    "studentLevel": "high_school", // or 'college' or 'both'
    "ageFilter": "Age 16-24",
    "isFree": true, // false if fee required
    "scamFlag": false, // true if scam suspected
    "scamReason": "Only if scamFlag is true, otherwise empty",
    "requirements": ["GPA 3.0+", "1 essay"],
    "isVerified": true,
    "fieldOfStudy": "STEM", // or 'Health', 'Business', 'Any'
    "sourceUrl": "https://..."
  }
]
\`\`\`
Return only the json block with no other conversational markdown text. Use the Google Search tool to search for real live results.`,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.1,
        }
      });

      const rawText = response.text || "";
      console.log("[AI Update Engine] Received raw response from Gemini.");

      // Parse JSON from code block
      const jsonMatch = rawText.match(/```json([\s\S]*?)```/) || rawText.match(/```([\s\S]*?)```/);
      const cleanJson = jsonMatch ? jsonMatch[1].trim() : rawText.trim();

      let parsedScholarships = JSON.parse(cleanJson);
      if (!Array.isArray(parsedScholarships)) {
        throw new Error("Parsed scholarship response is not an array");
      }

      // Add a tag to record origin query and merge with existing list
      parsedScholarships = parsedScholarships.map((s, index) => ({
        ...s,
        id: s.id || `sch-ai-${Date.now()}-${index}`,
        originalQuery: query,
        isVerified: !s.scamFlag,
      }));

      // Prune & Automatic review filters:
      // The user requested checking if a scholarship requires a fee or asks sensitive data and auto flagging or deleting.
      // We will FLAG or automatically move verified ones to active, and scams to a flagged list.
      // Avoid inserting duplicates
      parsedScholarships.forEach(newSch => {
        const duplicateIndex = dynamicScholarships.findIndex(
          existing => existing.name.toLowerCase() === newSch.name.toLowerCase()
        );
        if (duplicateIndex >= 0) {
          dynamicScholarships[duplicateIndex] = { ...dynamicScholarships[duplicateIndex], ...newSch };
        } else {
          dynamicScholarships.unshift(newSch); // Add new at the top
        }
      });

      res.json({
        success: true,
        scholarships: dynamicScholarships,
        addedCount: parsedScholarships.length
      });

    } catch (e: any) {
      console.error("[AI Update Engine] Error parsing scholarship data:", e);
      res.json({
        success: false,
        error: e.message || "Failed to parse scholarships generated by AI.",
        scholarships: dynamicScholarships
      });
    }
  });


  // API Route: Get Internships list
  app.get("/api/internships", (req, res) => {
    res.json(dynamicInternships);
  });

  // API Route: Use Gemini with Google Search tool to search and verify internships
  app.post("/api/internships/update", async (req, res) => {
    const { searchQuery } = req.body;
    const query = searchQuery || "legitimate high school college internships software biology business 2026";

    console.log(`[AI Update Engine] Searching for new internships with query: "${query}"`);

    const geminiKey = process.env.GEMINI_API_KEY;
    if (!geminiKey || geminiKey === "MY_GEMINI_API_KEY") {
      console.log("[AI Update Engine] GEMINI_API_KEY is not configured for internships. Using pre-seeded dataset.");
      return res.json({
        success: false,
        error: "GEMINI_API_KEY is not configured in the system Secrets. Showing default pre-seeded internships.",
        internships: dynamicInternships
      });
    }

    try {
      const ai = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Search Google for real, open or upcoming student internship positions in the USA matching query: "${query}". 
Collect at least 3 legitimate positions. For EACH internship, extract:
1. Internship Title
2. Employer Company
3. Location (e.g. Remote, or Hybrid in Seattle, WA)
4. Salary Type (Paid or Unpaid or Stipend)
5. Application Deadline (as YYYY-MM-DD or "Rolling")
6. Student level (undergrad, grad, high_school, or all)
7. Brief Description
8. Core Requirements
9. Authentic application source link.
10. SUSPECTED SCAM inspection: Is this a potential job scam or money processing mule? If it demands training fees, onboarding registration fees, direct bank access info before interview, or is suspicious, flag scamFlag: true and list the scamReason.

Format the response EXACTLY as a single raw JSON array conforming to this TypeScript template:
\`\`\`json
[
  {
    "id": "int-[unique string]",
    "title": "Internship Title",
    "company": "Company Name",
    "location": "Remote / Hybrid (City, State)",
    "type": "Paid", // or 'Unpaid'
    "deadline": "2026-12-15",
    "studentLevel": "undergrad", // 'grad', 'high_school', 'all'
    "description": "Brief text details",
    "requirements": ["Coursework in STEM", "Python"],
    "isVerified": true,
    "scamFlag": false,
    "scamReason": "",
    "sourceUrl": "https://...",
    "fieldOfStudy": "Engineering" // or 'Business', 'Health', 'Any'
  }
]
\`\`\`
Return only the json code block with no conversational wrapper. Use the Google Search tool to search for real results.`,
        config: {
          tools: [{ googleSearch: {} }],
          temperature: 0.1,
        }
      });

      const rawText = response.text || "";

      const jsonMatch = rawText.match(/```json([\s\S]*?)```/) || rawText.match(/```([\s\S]*?)```/);
      const cleanJson = jsonMatch ? jsonMatch[1].trim() : rawText.trim();

      let parsedInternships = JSON.parse(cleanJson);
      if (!Array.isArray(parsedInternships)) {
        throw new Error("Parsed internships result is not an array");
      }

      parsedInternships = parsedInternships.map((intern, index) => ({
        ...intern,
        id: intern.id || `int-ai-${Date.now()}-${index}`,
        isVerified: !intern.scamFlag
      }));

      // Merge into dynamic in-memory array
      parsedInternships.forEach(newInt => {
        const duplicateIndex = dynamicInternships.findIndex(
          existing => existing.title.toLowerCase() === newInt.title.toLowerCase() && existing.company.toLowerCase() === newInt.company.toLowerCase()
        );
        if (duplicateIndex >= 0) {
          dynamicInternships[duplicateIndex] = { ...dynamicInternships[duplicateIndex], ...newInt };
        } else {
          dynamicInternships.unshift(newInt);
        }
      });

      res.json({
        success: true,
        internships: dynamicInternships,
        addedCount: parsedInternships.length
      });

    } catch (e: any) {
      console.error("[AI Update Engine] Error parsing internship data:", e);
      res.json({
        success: false,
        error: e.message || "Failed to parse internships retrieved by AI.",
        internships: dynamicInternships
      });
    }
  });


  // Serve static assets in production, otherwise Vite handles development
  if (process.env.NODE_ENV === "production") {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));

    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server launched on port ${PORT}`);
    console.log(`Vite development server active...`);
  });
}

startServer();
